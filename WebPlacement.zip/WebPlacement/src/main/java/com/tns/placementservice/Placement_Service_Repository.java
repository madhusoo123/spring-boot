package com.tns.placementservice;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Placement_Service_Repository extends JpaRepository<Placement, Integer> 
{

}
